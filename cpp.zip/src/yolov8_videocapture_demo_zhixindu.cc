// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

/*-------------------------------------------
                Includes
-------------------------------------------*/
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>
#include <termios.h>

#include "yolov8.h"
#include <opencv2/opencv.hpp>

#define PATH_DIR_LENS	(256)
#define DEVICE_DIR	"/dev"
#define DEVICE_NAME	"ttyS1"
#define DEVICE_NAME_1	"ttyS2"
#define HZ_BUF "HZHY Board Test Message"

/*-------------------------------------------
                  Functions
-------------------------------------------*/
UartInfoObj UartInfo1 = {0};
UartInfoObj UartInfo = {0};
char write_buf1[] = "\r\n";
char text_start[2]={0xFF,0xAA};
char text_stop[2]={0xFF,0xAB};
char mode_flag=0;
char detect_on=0;
double __get_us(struct timeval t) { return (t.tv_sec * 1000000 + t.tv_usec); }

int ut_write(UartInfoHandle hUartInfo,const char *data,size_t len)
{
return write(hUartInfo->fd,data,len);
}

int flush_uart_buffer(UartInfoHandle hUartInfo)
{
if(tcflush(hUartInfo->fd,TCIOFLUSH)==0)
{
printf("kong kong kong \n");
return 0;
}else {
printf("kong error\n");
return -1;}
}
int uart_open_fir1() 
{
    int ret1;
    //char write_buf1[] = "\r\n";
       // UartInfoObj UartInfo = {0};
    char dev_path[PATH_DIR_LENS];
     
    // 构建完整的文件路径
    sprintf(dev_path, "%s/%s",DEVICE_DIR ,DEVICE_NAME); 
    UartInfo.device = dev_path;
    UartInfo.read_timeout = 0;
    UartInfo.write_timeout = 0;
    UartInfo.UartConfig.baudrate = 9600;
    UartInfo.UartConfig.dbit = 8;
    UartInfo.UartConfig.parity = 'N';
    UartInfo.UartConfig.sbit = 1;

    ret1 = UartOpen(&UartInfo);
    if (ret1)
    {
    printf("uart1 open error\n");
	return -1;
    }

}
/*
int uart_open_fir2() 
{
    int ret2;
    char write_buf[] = "HZHY Board Test Message";
        //UartInfoObj UartInfo1 = {0};
    char dev_path1[PATH_DIR_LENS];
     
    // 构建完整的文件路径
    sprintf(dev_path1, "%s/%s",DEVICE_DIR ,DEVICE_NAME_1); 
    UartInfo1.device = dev_path1;
    UartInfo1.read_timeout = 0;
    UartInfo1.write_timeout = 0;
    UartInfo1.UartConfig.baudrate = 9600;
    UartInfo1.UartConfig.dbit = 8;
    UartInfo1.UartConfig.parity = 'E';
    UartInfo1.UartConfig.sbit = 1;

    ret2 = UartOpen(&UartInfo1);
    if (ret2)
    {
    printf("uart2 open error\n");
	return -1;
    }

}
*/

// 处理图像并发送
void save_and_send_image(const cv::Mat& frame) {
    /*std::vector<uchar> buf;
    std::vector<int> compression_params;
    compression_params.push_back(cv::IMWRITE_JPEG_QUALITY);
    compression_params.push_back(50);

    bool success = cv::imencode(".jpg", frame, buf, compression_params);
    if (!success) {
        printf("Error: Could not compress image\n");
        return;
    }

    size_t buf_size = buf.size();
    char* data = reinterpret_cast<char*>(buf.data());
    UartWrite(&UartInfo, data, buf_size);
    printf("Compressed image sent through UART\n");
    usleep(8000);
    */
    std::vector<uchar> buf;
    std::vector<int> compression_params;
    compression_params.push_back(cv::IMWRITE_JPEG_QUALITY);
    compression_params.push_back(50);  // 压缩质量

    // 压缩图像为JPEG格式
    bool success = cv::imencode(".jpg", frame, buf, compression_params);
    if (!success) {
        printf("Error: Could not compress image\n");
        return;
    }
    std::string filename ="output_img.jpg";
    cv::imwrite(filename, frame);
    size_t buf_size = buf.size();
    size_t chunk_size = 2048;  // 每次发送的最大数据块大小（字节）
    size_t total_sent = 0;     // 已发送的总字节数
     //char* data = reinterpret_cast<char*>(buf.data());
    //ut_write(&UartInfo,data,buf_size);
    //UartWrite(&UartInfo, &buf.data, buf_size);
       printf("busize :  %zu\n", buf_size);
    // 将数据分块发送
    /*

    for(int i =0;i<4096;i++)
    {
    char data = 0x01;
    ut_write(&UartInfo,&data,1);
    }
       usleep(5000000);  // 休眠8毫秒
     //flush_uart_buffer(&UartInfo);
      for(int i =0;i<4096;i++)
    {
    char data = 0x02;
    ut_write(&UartInfo,&data,1);
    }
    */
        int aaa =0;
    while (total_sent < buf_size) {
    aaa+=1;
        size_t remaining_size = buf_size - total_sent;
        size_t current_chunk_size = (remaining_size > chunk_size) ? chunk_size : remaining_size;
        char* data = reinterpret_cast<char*>(buf.data() + total_sent);
        //UartWrite(&UartInfo, data, current_chunk_size);
        ut_write(&UartInfo,data,current_chunk_size);
        total_sent += current_chunk_size;
       usleep(2300000);  // 休眠8毫秒
}

	printf("jishu :  %d\n", aaa);
        usleep(2500000);  // 休眠8毫秒
}


/*-------------------------------------------
                  Main Function
-------------------------------------------*/
int main(int argc, char **argv)
{
    if (argc != 3)
    {
        printf("%s <model path> <camera device id/video path>\n", argv[0]);
        printf("Usage: %s  yolov8s.rknn  0 \n", argv[0]);
        printf("Usage: %s  yolov8s.rknn /path/xxxx.mp4\n", argv[0]);
        return -1;
    }

    const char *model_path = argv[1];
    const char *device_name = argv[2];
 char uart_buffer[10];  // 存储从UART2接收到的指令

    int ret;
    //uart_open_fir2();
    uart_open_fir1();
   /*
    //add
    int ret1;
    char write_buf[] = "HZHY Board Test Message";
        UartInfoObj UartInfo = {0};
    char dev_path[PATH_DIR_LENS];
    // 构建完整的文件路径
    sprintf(dev_path, "%s/%s",DEVICE_DIR ,DEVICE_NAME); 
    UartInfo.device = dev_path;
    UartInfo.read_timeout = 0;
    UartInfo.write_timeout = 0;
    UartInfo.UartConfig.baudrate = 115200;
    UartInfo.UartConfig.dbit = 8;
    UartInfo.UartConfig.parity = 'N';
    UartInfo.UartConfig.sbit = 1;

    ret1 = UartOpen(&UartInfo);
    if (ret1)
    {
    printf("uart open error\n");
	return -1;
    }
    
     ret1 = UartWrite(&UartInfo, write_buf, sizeof(write_buf));
	    if (ret1 <= 0) 
	    {
		printf("Send buf error:%d\n", ret1);
		return -1;
	    }
	    printf("Send OK:(%s)\n", write_buf);
	    */
    //add end


    cv::Mat image, frame;
    struct timeval start_time, stop_time;
    rknn_app_context_t rknn_app_ctx;
    image_buffer_t src_image;
    object_detect_result_list od_results;

    memset(&rknn_app_ctx, 0, sizeof(rknn_app_context_t));
    memset(&src_image, 0, sizeof(image_buffer_t));

    cv::VideoCapture cap;
    //if (strlen(device_name)==2 && isdigit(device_name[0])) {
    if (isdigit(device_name[0])) {
        // 打开摄像头
        int camera_id = atoi(argv[2]);
        cap.open(camera_id);
        if (!cap.isOpened()) {
            printf("Error: Could not open camera.\n");
            return -1;
        }
        //cap.set(cv::CAP_PROP_FRAME_WIDTH, 640);//宽度
        //cap.set(cv::CAP_PROP_FRAME_HEIGHT, 480);//高度
        cap.set(cv::CAP_PROP_FRAME_WIDTH,640);//宽度
        cap.set(cv::CAP_PROP_FRAME_HEIGHT,480);//高度
    } else {
        // 打开视频文件
        cap.open(argv[2]);
        if (!cap.isOpened()) {  
            printf("Error: Could not open video file.\n");
            return -1;
        }
    }

    // 初始化
    init_post_process();
    ret = init_yolov8_model(model_path, &rknn_app_ctx);
    if (ret != 0)
    {
        printf("init_yolov8_seg_model fail! ret=%d model_path=%s\n", ret, model_path);
        goto out;
    }

    // 推理，画框，显示
	while(true) {
        gettimeofday(&start_time, NULL);

        if (!cap.read(frame)) {  
            printf("cap read frame fail!\n");
            break;  
        }  

    // 接收 UART2 数据（拍照指令）
        int bytes_read = UartRead(&UartInfo, uart_buffer, sizeof(uart_buffer));
        if (bytes_read > 0) {
            if (uart_buffer[0] == 0x31) {  // 假设 'P' 是拍照指令
                save_and_send_image(frame);  // 保存并发送图像
                // sleep(60);  // 休眠8毫秒
            }else if (uart_buffer[0] == 0x32) {  // shoudong mode
               // save_and_send_image(frame);  // 保存并发送图像
                mode_flag=1;
                printf("shoudong mode!\n");
                // sleep(60);  // 休眠8毫秒
            }else if (uart_buffer[0] == 0x33) {  // zidong mode
                mode_flag=0;
                printf("zidong mode!\n");
                // sleep(60);  // 休眠8毫秒
            }
            else if (uart_buffer[0] == 0x34) {  // shoudong mode
                detect_on=1;
                printf("detect!\n");
                // sleep(60);  // 休眠8毫秒
            }
        }
        
         
        cv::cvtColor(frame, image, cv::COLOR_BGR2RGB);
        src_image.width  = image.cols;
        src_image.height = image.rows;
        src_image.format = IMAGE_FORMAT_RGB888;
        src_image.virt_addr = (unsigned char*)image.data;

        ret = inference_yolov8_model(&rknn_app_ctx, &src_image, &od_results);
        if (ret != 0)
        {
            printf("init_yolov8_seg_model fail! ret=%d\n", ret);
            goto out;
        }

        // draw boxes
        char text[256];
        char result[1024];
        if (mode_flag==0)//zidongmoshi 
        {
        UartWrite(&UartInfo, text_start, 2);// 通过串口1发送目标检测结果
        for (int i = 0; i < od_results.count; i++)
        {
            object_detect_result *det_result = &(od_results.results[i]);
            printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
                det_result->box.left, det_result->box.top,
                det_result->box.right, det_result->box.bottom,
                det_result->prop);
                float confidence_yuzhi =0.5;
                
            int x1 = det_result->box.left;
            int y1 = det_result->box.top;
            int x2 = det_result->box.right;
            int y2 = det_result->box.bottom;
	      int width = x2 - x1;
	      int height =y2 -y1;
	      if(det_result->cls_id==4 || det_result->cls_id==5)
	      {
	      confidence_yuzhi=0.7;
	      }
                if ( det_result->prop > confidence_yuzhi)
         {
         if(width<620 && height<460)
         {
            sprintf(result, "%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
                det_result->box.left, det_result->box.top,
                det_result->box.right, det_result->box.bottom,
                det_result->prop);

            ret = UartWrite(&UartInfo, result, strlen(result));// 通过串口1发送目标检测结果
            
	            if (ret <= 0) 
	             {
		        printf("Send buf error:%d\n", ret);
		        return -1;
	            }
	            printf("Dected Send OK\n");
	   }
	   }
	   
	          //UartWrite(&UartInfo, write_buf1, strlen(write_buf1));// 通过串口1发送目标检测结果write_buf1
	             
            //uart_write(uart_fd_1, result, strlen(result));  // 通过串口1发送目标检测结果


	    
            rectangle(frame, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(255, 0, 0, 255), 2);//在frame上绘制矩形，矩形的边框线粗细为2个像素。
            sprintf(text, "%s %.1f%%", coco_cls_to_name(det_result->cls_id), det_result->prop * 100);
            putText(frame, text, cv::Point(x1, y1 - 6), cv::FONT_HERSHEY_DUPLEX, 0.7, cv::Scalar(0,0,255), 1, cv::LINE_AA);
        }
                UartWrite(&UartInfo, text_stop, 2);// 通过串口1发送目标检测结果
}	
		
		 if (mode_flag==1)
        {
        if(detect_on==1)
        {
        UartWrite(&UartInfo, text_start, 2);// 通过串口1发送目标检测结果
        for (int i = 0; i < od_results.count; i++)
        {
            object_detect_result *det_result = &(od_results.results[i]);
            printf("%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
                det_result->box.left, det_result->box.top,
                det_result->box.right, det_result->box.bottom,
                det_result->prop);
                if ( det_result->prop > 0.5)
         {
            sprintf(result, "%s @ (%d %d %d %d) %.3f\n", coco_cls_to_name(det_result->cls_id),
                det_result->box.left, det_result->box.top,
                det_result->box.right, det_result->box.bottom,
                det_result->prop);

            ret = UartWrite(&UartInfo, result, strlen(result));// 通过串口1发送目标检测结果
            
	            if (ret <= 0) 
	             {
		        printf("Send buf error:%d\n", ret);
		        return -1;
	            }
	            printf("Dected Send OK\n");
	   }
	          //UartWrite(&UartInfo, write_buf1, strlen(write_buf1));// 通过串口1发送目标检测结果write_buf1
	             
            //uart_write(uart_fd_1, result, strlen(result));  // 通过串口1发送目标检测结果


            int x1 = det_result->box.left;
            int y1 = det_result->box.top;
            int x2 = det_result->box.right;
            int y2 = det_result->box.bottom;

            rectangle(frame, cv::Point(x1, y1), cv::Point(x2, y2), cv::Scalar(255, 0, 0, 255), 2);//在frame上绘制矩形，矩形的边框线粗细为2个像素。
            sprintf(text, "%s %.1f%%", coco_cls_to_name(det_result->cls_id), det_result->prop * 100);
            putText(frame, text, cv::Point(x1, y1 - 6), cv::FONT_HERSHEY_DUPLEX, 0.7, cv::Scalar(0,0,255), 1, cv::LINE_AA);
        }
                UartWrite(&UartInfo, text_stop, 2);// 通过串口1发送目标检测结果
                detect_on=0;
                
    }	
}
		
		// 计算FPS
        gettimeofday(&stop_time, NULL);//使用gettimeofday函数记录当前时间，将结果存储在 stop_time变量中。gettimeofday返回一个包含秒和微秒的结构体，用于计算处理帧的耗时。
        float t = (__get_us(stop_time) - __get_us(start_time))/1000;//t是以毫秒计算单位的，将结果除以1000，将当前时间和开始时间计算差值后初转成us。
        printf("Infer time(ms): %f ms\n", t);//输出这一帧的推理时间
		putText(frame, cv::format("FPS: %.2f", 1.0 / (t / 1000)), cv::Point(10, 30), cv::FONT_HERSHEY_PLAIN, 2.0, cv::Scalar(255, 0, 0), 2, 8);//计算FPS：1.0/(t/1000)，其中t/1000将时间转换为秒，1.0 /(t/1000)表示每秒可以处理的帧数（FPS）
		cv::imshow("YOLOv8 C++ Demo", frame);//将处理后的 frame 显示在一个名为 "YOLOv8 C++ Demo" 的窗口中。这一帧的图像包含检测框和FPS信息

		char c = cv::waitKey(1);//等待键盘输入1毫秒,返回按下的键。如果返回值为27(即ESC键)，则退出循环。
		if (c == 27) { // ESC
			break;
		}

    }

out:
    deinit_post_process();
    //UartClose(&UartInfo1);
    UartClose(&UartInfo);
    ret = release_yolov8_model(&rknn_app_ctx);
    if (ret != 0)
    {
        printf("release_yolov8_seg_model fail! ret=%d\n", ret);
    }

    return 0;
}

#ifndef HZUART_H
#define HZUART_H

#include <stdint.h>


typedef struct _tagUartConfigObj
{
    unsigned int    baudrate;	/* 波特率 */
    unsigned char   dbit;	/* 数据位 */
    char	    parity;	/* 奇偶校验 */
    unsigned char   sbit;	/* 停止位 */
    unsigned char   rts_cts;	/* 流控位 */
}UartConfigObj, *UartConfigHandle;

typedef struct _tagUartInfoObj
{
    int	    fd;
    char    *device;		/* 串口设备 */
    int	    read_timeout;	/* 读取超时时间 */
    int	    write_timeout;	/* 写入超时时间 */
    UartConfigObj UartConfig;
}UartInfoObj, *UartInfoHandle;


int UartOpen(UartInfoHandle hUartInfo);
int UartRead(UartInfoHandle hUartInfo, char *buf, size_t size);
int UartWrite(UartInfoHandle hUartInfo, char *buf, size_t size);
void UartClose(UartInfoHandle hUartInfo);

#endif

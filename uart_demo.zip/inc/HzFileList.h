#ifndef HZ_FILE_LIST
#define HZ_FILE_LIST


int fileList(char *path);


#endif

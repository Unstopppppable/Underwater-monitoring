#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/select.h>
#include <termios.h>
#include "HzUart.h"


int UartCfg(UartInfoHandle hUartInfo)
{
    UartConfigHandle hUartConfig = &hUartInfo->UartConfig; 
    struct termios new_cfg = {0};
    speed_t speed;

    /* 设置为原始模式 */
    cfmakeraw(&new_cfg);
    
    /* 使能接收 */
    new_cfg.c_cflag |= CREAD;

    /* 设置波特率 */
    switch (hUartConfig->baudrate) 
    {
	case 1200: 
	    speed = B1200;
	    break;
	case 1800: 
	    speed = B1800;
	    break;
	case 2400: 
	    speed = B2400;
	    break;
	case 4800: 
	    speed = B4800;
	    break;
	case 9600: 
	    speed = B9600;
	    break;
	case 19200: 
	    speed = B19200;
	    break;
	case 38400: 
	    speed = B38400;
	    break;
	case 57600: 
	    speed = B57600;
	    break;
	case 115200: 
	    speed = B115200;
	    break;
	case 230400: 
	    speed = B230400;
	    break;
	default: 
	    /* 默认配置为 115200 */
	    speed = B115200;
        break;
    }

    if (0 > cfsetspeed(&new_cfg, speed)) 
    {
	fprintf(stderr, "cfsetspeed error: %s\n", strerror(errno));
	return -1;
    }

    /* 设置数据位大小 */
    new_cfg.c_cflag &= ~CSIZE; //将数据位相关的比特位清零
    switch (hUartConfig->dbit) 
    {
	case 7:
	    new_cfg.c_cflag |= CS7;
	    break;
	case 8:
	    new_cfg.c_cflag |= CS8;
	    break;
	default: 
	    /* 默认数据位大小为 8 */
	    new_cfg.c_cflag |= CS8;
	    break;
    }

    /* 设置奇偶校验 */
    switch (hUartConfig->parity) 
    {
	case 'N': //无校验
	    new_cfg.c_cflag &= ~PARENB;
	    new_cfg.c_iflag &= ~INPCK;
	    break;
	case 'O': //奇校验
	    new_cfg.c_cflag |= (PARODD | PARENB);
	    new_cfg.c_iflag |= INPCK;
	    break;
	case 'E': //偶校验
	    new_cfg.c_cflag |= PARENB;
	    new_cfg.c_cflag &= ~PARODD; /* 清除 PARODD 标志，配置为偶校验 */
	    new_cfg.c_iflag |= INPCK;
	    break;
	default: //默认配置为无校验
	    new_cfg.c_cflag &= ~PARENB;
	    new_cfg.c_iflag &= ~INPCK;
	    break;
    }

    /* 设置停止位 */
    switch (hUartConfig->sbit) 
    {
	case 1: 
	    //1 个停止位
	    new_cfg.c_cflag &= ~CSTOPB;
	    break;
	case 2: 
	    //2 个停止位
	    new_cfg.c_cflag |= CSTOPB;
	    break;
	default: 
	    //默认配置为 1 个停止位
	    new_cfg.c_cflag &= ~CSTOPB;
	    break;
    }

    /* 将 MIN 和 TIME 设置为 0 */
    new_cfg.c_cc[VTIME] = 0;
    new_cfg.c_cc[VMIN] = 0;

    new_cfg.c_cflag &= ~CRTSCTS;   //关闭硬件流控制
    new_cfg.c_iflag &= ~(IXON | IXOFF |IXANY);  //取消软件流控制

    /* 清空缓冲区 */
    if (0 > tcflush(hUartInfo->fd, TCIOFLUSH)) 
    {
	fprintf(stderr, "tcflush error: %s\n", strerror(errno));
	return -1;
    }
    /* 写入配置、使配置生效 */
    if (0 > tcsetattr(hUartInfo->fd, TCSANOW, &new_cfg)) 
    {
	fprintf(stderr, "tcsetattr error: %s\n", strerror(errno));
	return -1;
    }

    return 0;
}


int UartOpen(UartInfoHandle hUartInfo)
{
    hUartInfo->fd = open(hUartInfo->device, O_RDWR | O_NOCTTY | O_NONBLOCK);
    if (hUartInfo->fd < 0) 
    {
	fprintf(stderr, "open error: %s: %s\n", hUartInfo->device, strerror(errno));
	return -1;
    }
   
    UartCfg(hUartInfo);

    return 0;
}


int UartRead(UartInfoHandle hUartInfo, char *buf, size_t size)
{
    int ready_fds;
    struct timeval timeout;
    fd_set read_fds;
    int total = 0, cnt = 0;
    char *p_buf = buf;
    
    
    while (1)
    {
	FD_ZERO(&read_fds);	
	FD_SET(hUartInfo->fd, &read_fds);
	
	switch (hUartInfo->read_timeout)
	{
	    case -1:
		ready_fds = select(hUartInfo->fd + 1, &read_fds, NULL, NULL, NULL);
		break;

	    case 0:
		timeout.tv_sec = 0;
		timeout.tv_usec = 0;
		ready_fds = select(hUartInfo->fd + 1, &read_fds, NULL, NULL, &timeout);
		break;

	    default:
		if (hUartInfo->read_timeout > 1000)
		{
		    timeout.tv_sec = hUartInfo->read_timeout / 1000;
		    timeout.tv_usec = (hUartInfo->read_timeout % 1000) * 1000;
		}
		else
		{
		    timeout.tv_sec = 0;
		    timeout.tv_usec = hUartInfo->read_timeout * 1000;
		}
		ready_fds = select(hUartInfo->fd + 1, &read_fds, NULL, NULL, &timeout);
		break;
	}

	if (ready_fds < 0) 
	{
	    return -errno;	
	} 
	else if (ready_fds == 0) 
	{
	    break;
	}

	cnt = read(hUartInfo->fd, p_buf, size);
	if (cnt <= 0)
	{
	    if (cnt == 0)
	    {
		break;
	    }
	    if (errno == EAGAIN || errno == EWOULDBLOCK) 
	    {
		break;
	    }
	    else
	    {
		return -errno;
	    }
	}
	p_buf += cnt;
	total += cnt;
	size -= cnt;
	if (size <= 0)
	{
	    break;
	}
    }
    return total;
}



int UartWrite(UartInfoHandle hUartInfo, char *buf, size_t size)
{
    int ret;
    int ready_fds;
    int total = 0;
    fd_set write_fds;
    char *p_buf = buf;
    size_t cnt = size;
    struct timeval timeout;

    while (1)
    {
	FD_ZERO(&write_fds);	
	FD_SET(hUartInfo->fd, &write_fds);
	if (hUartInfo->write_timeout < 0)
	{
	    ready_fds = select(hUartInfo->fd + 1, &write_fds, NULL, NULL, NULL); 
	}
	else if (hUartInfo->write_timeout == 0)
	{
	    timeout.tv_sec = 0;
	    timeout.tv_usec = 0;
	    ready_fds = select(hUartInfo->fd + 1, &write_fds, NULL, NULL, &timeout);
	}
	else
	{
	    if (hUartInfo->write_timeout > 1000)
	    {
		timeout.tv_sec = hUartInfo->write_timeout / 1000;
		timeout.tv_usec = (hUartInfo->write_timeout % 1000) * 1000;
	    }
	    else
	    {
		timeout.tv_usec = hUartInfo->write_timeout * 1000;
	    }
	    ready_fds = select(hUartInfo->fd + 1, &write_fds, NULL, NULL, &timeout);
	}

	if (ready_fds < 0) 
	{
	    return -errno;	
	} 

	ret = write(hUartInfo->fd, p_buf + total, cnt - total);
	if (ret <=  0)
	{
	    if (total > 0)
		break;
	    else
		return -errno;
	}
	total += ret;
    }   

    return total;
}


void UartClose(UartInfoHandle hUartInfo)
{
    close(hUartInfo->fd); 
}


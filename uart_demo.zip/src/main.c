#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include "HzUart.h"
#include "HzFileList.h"

#define PATH_DIR_LENS	(256)
#define DEVICE_DIR	"/dev"
#define HZ_BUF "HZHY Board Test Message"

void ShowHelp(char *prog)
{
    int ret;
    puts("Usage:");
    printf("  %s <device> {-r | -w}\n", prog);
    puts("\nArguments:\n"
	 "  device\tuart device, eg: ttyS<n>\n"
	 "Options:\n"
	 "  -w\t\tsend message\n"
	 "  -r\t\trecv message\n");
    puts("Automatic serial of device node information");
    ret = fileList(DEVICE_DIR);
    if (ret < 0)
    {
	printf("Get Node Error\n");
    }
}


int main(int argc, char *argv[])
{   
    int ret;
    char read_buf[512] = {0};
    char write_buf[] = "HZHY Board Test Message";
    
    if (argc < 3)
    {
	ShowHelp(argv[0]);
	return -1;
    }

    UartInfoObj UartInfo = {0};
    char dev_path[PATH_DIR_LENS];
    
    // 构建完整的文件路径
    sprintf(dev_path, "%s/%s",DEVICE_DIR ,argv[1]); 
    UartInfo.device = dev_path;
    UartInfo.read_timeout = 0;
    UartInfo.write_timeout = 0;
    UartInfo.UartConfig.baudrate = 115200;
    UartInfo.UartConfig.dbit = 8;
    UartInfo.UartConfig.parity = 'N';
    UartInfo.UartConfig.sbit = 1;

    ret = UartOpen(&UartInfo);
    if (ret)
    {
	ShowHelp(argv[0]);
	return -1;
    }
    
    
    if (!strcmp(argv[2], "-w"))
    {
	while (1)
	{
	    ret = UartWrite(&UartInfo, write_buf, sizeof(write_buf));
	    if (ret <= 0) 
	    {
		printf("Send buf error:%d\n", ret);
		return -1;
	    }
	    printf("Send OK:(%s)\n", write_buf);
	    sleep(1);
	}
    }
    else if (!strcmp(argv[2], "-r"))
    {
	while (1)
	{
	    ret = UartRead(&UartInfo, read_buf, sizeof(read_buf));
	    if (ret < 0)
	    {
	    	printf("Read buf error\n");
		return -1;
	    }
	    else if (ret > 0)
	    {
		printf("%s\n", read_buf);
		memset(read_buf, 0x0, sizeof(read_buf));
	    }
	    sleep(1);
	}
    }
    UartClose(&UartInfo);

    return 0;
}

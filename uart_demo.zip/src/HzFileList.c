#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <linux/input.h>
#include "HzFileList.h"

#define PATH_DIR_LENS (512)

int fileList(char *dir_path) 
{
    DIR *dir;
    struct dirent   *dir_obj;
    struct stat	    file_stat;

    dir = opendir(dir_path);
    if (dir == NULL) 
    {
	printf("dir error\n");
	return -1;
    }

    while ((dir_obj = readdir(dir)) != NULL) 
    {
	char file_path[PATH_DIR_LENS];
	sprintf(file_path, "%s/%s", dir_path, dir_obj->d_name); 
	if (stat(file_path, &file_stat) == -1) 
	{
	    printf("Get Node Error\n");
	}

	if (S_ISCHR(file_stat.st_mode)) 
	{
	    if (!strncmp(dir_obj->d_name, "tty", 3))
	    {
		if (*(dir_obj->d_name + 3) >= '0' && *(dir_obj->d_name + 3)  <= '9')
		{
		   ; 
		}
		else
		{
		    if (!strcmp(dir_obj->d_name, "tty"))
		    {
			break;
		    }
		    printf("  device:\t%s\n", dir_obj->d_name);
		}
	    }

	}
    }
    puts("");

    // 关闭文件夹
    closedir(dir);

    return 0;
}

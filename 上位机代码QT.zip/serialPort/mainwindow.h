#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include "handledata.h"
#include "serialthread.h"
#include <QMainWindow>
#include"win_qextserialport.h"
#include "qextserialbase.h"
#include "autosenddata.h"
#include"QTimerEvent"
#include"showwave.h"
#include"QTimer"
#include"QSystemTrayIcon"
#include "aboutform.h"
#include <QThread>
#include <QPixmap>
#include <QPainter>
#include <QRect>
#include <QString>
#include <QLabel>
#include "CustomLabel.h"
#include "qcustomplot.h"


//#include "collectdata.h"

extern QByteArray readData;

namespace Ui {
    class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private:
    Ui::MainWindow *ui;
    Win_QextSerialPort *myCom;
    Thread_one *thread_1;
    bool stopShow;
    QString strSelectFileData;
    AutoSendData *autoSendTime;
    bool showHexFlag;

    showWave sw;
    int timeId;
    QByteArray temp;
    QByteArray temp1;

    QSystemTrayIcon *sysIcon;
    QMenu *menu;
    QAction *exitAct,*aboutAct;
    HandleData *hd;
    AboutForm af;
    QTimer *time ;
    QByteArray buffer; // 用于保存串口接收到的完整缓冲数据
    QByteArray buffer111; // 用于保存串口接收到的完整缓冲数据

    CustomLabel *label; // 使用自定义 QLabel
    QTimer *timer_count;
    QTimer *flagResetTimer;

    //Thread---Handle_data
    QCustomPlot *customPlot; // 声明 QCustomPlot 指针

    QVector<double> xData;    // 存储所有点的x坐标
        QVector<double> yTData;   // 存储T曲线的y值
        QVector<double> yDData;   // 存储D曲线的y值
        QVector<double> yPData;   // 存储P曲线的y值
        int currentX = 0;         // 当前横坐标值
    //Thread---Handle_data
        QScrollBar *horizontalScroll; // 水平滚动条
        bool autoScroll = true;    // 是否自动滚动到最新数据
        QTextCodec *gbkCodec = QTextCodec::codecForName("GBK"); // 根据实际编码调整
        QByteArray serialBuffer; // 串口数据缓冲区
        const QByteArray FRAME_HEADER = QByteArray::fromHex("CEC2");
        const QByteArray FRAME_FOOTER = QByteArray::fromHex("D70A");
        static const int FRAME_SIZE = 24;  // 固定帧长度（根据实际协议调整）
private slots:
    void sendDataBtn();
    void openSerial();
    void closeSerial();
    void showWaveBtn();
    void closeWindow();
    void clearSendArea();
    void clearReceiveDataArea();
    void stopShowData();
    void saveShowData();
    void SelectSendFileData();
    void sendFileData();
    void autoSendTimeSet();
    void showPlainText();
    //void timerEvent(QTimerEvent *e);
    void timeToReadCom();
    //void startthread();
    QString convertToHex(const QByteArray &data);  // 声明该函数
    void processFrame(const QByteArray &frame);


    void iconSystemActived(QSystemTrayIcon::ActivationReason reason);
    void showAbout();

    void on_openSerial_clicked();
    void on_tack_photo_clicked();


    void on_sendDataBtn_clicked();
    void on_closeSerial_clicked();

    void on_tack_photo_3_clicked();


    void on_tack_photo_4_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_25_clicked();

    void on_pushButton_24_clicked();

    void on_pushButton_23_clicked();

    void on_tack_photo_2_clicked();
    void on_pushButton_18_clicked();


    void on_pushButton_21_clicked();

    void on_pushButton_19_clicked();

    void on_pushButton_4_clicked();
    void on_pushButton_27_clicked();


public:
    void initialSerial();
    void closeEvent(QCloseEvent* e);
    QString stringSpaceToHex(QByteArray str,char tag);
    void processShareData();
    void readMyCom();
    void readMyCom_photo();
    void save_image_from_hex(const QString& input_file, const QString& output_image_file);
    unsigned char hex_to_byte(const QString& hexStr);
    void startthread();
    void onDraw() ;
    void drawRectOnLabel(QLabel *label, const QString &data);
    void updateGreenLabelCount();
    void readMyCom_boom();
    void updateChartWithData(double T, double D, double P);
    void updateChartView(int startIndex);




};

#endif // MAINWINDOW_H

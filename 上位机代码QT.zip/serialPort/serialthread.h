#ifndef SERIALTHREAD_H
#define SERIALTHREAD_H

#include <QThread>
#include <QObject>
#include <QMutex>
#include <QDebug>

class Thread_one : public QThread
{
    Q_OBJECT
public:
    explicit Thread_one();
    QMutex pause1;

protected:
    void run();
};


#endif // SERIALTHREAD_H

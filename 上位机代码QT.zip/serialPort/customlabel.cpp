#include "CustomLabel.h"

CustomLabel::CustomLabel(QWidget *parent) : QLabel(parent) {}

void CustomLabel::addRectangle(const QRect &rect, const QString &text, float confidence) {
    rectangles.push_back({rect, text, confidence});
    update(); // 触发重绘
}

void CustomLabel::clearRectangles() {
    rectangles.clear();
    update(); // 触发重绘
}

void CustomLabel::paintEvent(QPaintEvent *event) {
    QLabel::paintEvent(event); // 调用父类的绘图方法

    QPainter painter(this);
    painter.setPen(QPen(Qt::red, 2)); // 设置矩形边框颜色和粗细

    for (const auto &rectData : rectangles) {
        // 绘制矩形框
        painter.drawRect(rectData.rect);

        // 绘制文字
        painter.setPen(Qt::blue);
        painter.setFont(QFont("Arial", 10, QFont::Bold));
        painter.drawText(rectData.rect.topLeft() - QPoint(0, 10),
                         QString("%1 %.1f%").arg(rectData.text).arg(rectData.confidence * 100));
    }
}

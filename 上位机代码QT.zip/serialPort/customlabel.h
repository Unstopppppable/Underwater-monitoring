#ifndef CUSTOMLABEL_H
#define CUSTOMLABEL_H


#include <QLabel>
#include <QPainter>
#include <QRect>
#include <QString>
#include <vector>

class CustomLabel : public QLabel {
    Q_OBJECT

public:
    explicit CustomLabel(QWidget *parent = nullptr);

    // 添加绘制数据
    void addRectangle(const QRect &rect, const QString &text, float confidence);

    // 清空绘制内容
    void clearRectangles();

protected:
    void paintEvent(QPaintEvent *event) override;

private:
    struct RectangleData {
        QRect rect;
        QString text;
        float confidence;
    };

    std::vector<RectangleData> rectangles; // 存储矩形框和文字信息
};

#endif // CUSTOMLABEL_H

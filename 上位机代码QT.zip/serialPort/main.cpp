//#include <QtGui/QApplication>
#include <QGuiApplication>
#include <QApplication>
#include "mainwindow.h"
#include "QTextCodec"
#include <QTextCodec>


bool read_display_mutex;
bool clickedShowWaveBtn;
int precision_data;
bool start;

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    QTextCodec *codec = QTextCodec::codecForName("utf-8");
    QTextCodec::setCodecForLocale(codec);
    //QTextCodec::setCodecForCStrings(codec);
    //QTextCodec::setCodecForTr(codec);

    MainWindow w;
    w.setWindowTitle("SerialPort Communication!");
    //w.onDraw();
    //w.drawRectOnLabel(ui->label_10,"jellfish @ (140 0 640 477) 0.671\n");
    //w.startthread();
    w.show();

    return a.exec();
}

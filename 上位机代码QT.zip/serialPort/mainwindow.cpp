#include "mainwindow.h"
#include "ui_mainwindow.h"
#include"QDebug"
#include"QMessageBox"
#include"windows.h"
#include"QFileDialog"
#include"QDesktopServices"
#include"QFile"
#include"stdlib.h"
#include"stdio.h"
#include"fstream"
#include <opencv2/core/core.hpp>
#include <opencv2/highgui/highgui.hpp>
#include <opencv2/imgproc/imgproc.hpp>
#include <QFile>
#include <QTextStream>
#include <QImage>
#include <QDebug>
#include <opencv2/opencv.hpp>
#include <string>
#include <vector>
#include <sstream>
#include <QPixmap>
#include <QPainter>
#include <QRect>
#include <QMap>
#include <QTimer>
#include <QtMath>  // for pow()
#include <QTextCodec>
using namespace std;
using namespace cv;

#define READ_DATA false
#define DISPLAY_DATA true

extern bool read_display_mutex;
extern bool clickedShowWaveBtn;
extern int precision_data;
int photo_flag=0;
int photo_num=0;
int boom_flag=0;
int photo_process=0;
int tongji_flag=0;

QByteArray readData;
QByteArray send_photo;
QByteArray shoudong_mode;
QByteArray zidong_mode;
QByteArray boom_send;
QByteArray detect;
QByteArray detect_wat;

QString photonum;
QString photoptr;
QString photoshowptr;

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    thread_1 = new Thread_one();
    time = new QTimer();
    stopShow=false;
    strSelectFileData="";
    readData = "";
    showHexFlag=false;
    precision_data = 8;
    //yuqi jia dingshiqi
    timer_count = new QTimer(this);
    flagResetTimer = new QTimer(this);
    flagResetTimer->setSingleShot(true);  // 只触发一次

    initialSerial();//初始化串口
    read_display_mutex = READ_DATA;
    clickedShowWaveBtn = false;

    sysIcon=new QSystemTrayIcon(this);
    QIcon icon=QIcon(trUtf8("./sysTray.png"));
    sysIcon->setIcon(icon);
    sysIcon->setToolTip(trUtf8("Freescale_Smart_Car && Qt_Software!"));
    sysIcon->show();
    sysIcon->showMessage("sysTrayIcon","Qt software is runnning!",QSystemTrayIcon::Information,8000);

    menu=new QMenu(this);
    exitAct=new QAction(QIcon(trUtf8("../exit.png")),trUtf8("&Exit"),this);
    aboutAct=new QAction(QIcon(trUtf8("../about.png")),trUtf8("&About"),this);

    menu->addAction(exitAct);
    menu->addAction(aboutAct);
    sysIcon->setContextMenu(menu);

    ui->sendDataBtn->setEnabled(false);
    ui->closeSerial->setEnabled(false);
    ui->showWaveBtn->setEnabled(false);
    ui->selectFileBtn->setEnabled(false);
    ui->clearReceiveBtn->setEnabled(false);
    ui->clearSendBtn->setEnabled(false);
    ui->saveShowData->setEnabled(false);
    ui->stopShowBtn->setEnabled(false);
    ui->sendDataEdit->setEnabled(false);
    ui->autoSend->setEnabled(false);
    ui->autoShowCheck->setEnabled(false);
    ui->hexShowCheck->setEnabled(false);
    ui->sendFileBtn->setEnabled(false);
    ui->eightPreRadio->setChecked(true);

    hd =new HandleData();

    connect(ui->sendDataBtn,SIGNAL(clicked()),this,SLOT(sendDataBtn()));
    //connect(ui->sendDataBtn,SIGNAL(clicked()),this,SLOT(readMyCom()));
    //connect(ui->sendFileBtn,SIGNAL(clicked()),this,SLOT(readMyCom()));
    connect(ui->closeSerial,SIGNAL(clicked()),this,SLOT(closeSerial()));
    connect(ui->openSerial,SIGNAL(clicked()),this,SLOT(openSerial()));
    connect(ui->showWaveBtn,SIGNAL(clicked()),this,SLOT(showWaveBtn()));
    connect(ui->closeWindow,SIGNAL(clicked()),this,SLOT(closeWindow()));
    connect(ui->clearSendBtn,SIGNAL(clicked()),this,SLOT(clearSendArea()));
    connect(ui->clearReceiveBtn,SIGNAL(clicked()),this,SLOT(clearReceiveDataArea()));
    connect(ui->stopShowBtn,SIGNAL(clicked()),this,SLOT(stopShowData()));
    connect(ui->saveShowData,SIGNAL(clicked()),this,SLOT(saveShowData()));
    connect(ui->selectFileBtn,SIGNAL(clicked()),this,SLOT(SelectSendFileData()));
    connect(ui->sendFileBtn,SIGNAL(clicked()),this,SLOT(sendFileData()));
    connect(ui->autoSend,SIGNAL(clicked()),this,SLOT(autoSendTimeSet()));
    connect(exitAct,SIGNAL(triggered()),this,SLOT(close()));
    connect(aboutAct,SIGNAL(triggered()),this,SLOT(showAbout()));
    connect(timer_count, &QTimer::timeout, this, &MainWindow::updateGreenLabelCount);
    // 连接定时器超时信号到槽函数
    connect(flagResetTimer, &QTimer::timeout, this, [=]() {
        qDebug() << "5秒内未收到数据，flag 置 0";
        boom_flag = 0;
    });

}

unsigned char MainWindow::hex_to_byte(const QString& hexStr) {
    unsigned char byte = 0;
    for (int i = 0; i < hexStr.size(); i++) {
        byte <<= 4;
        if (hexStr[i].isDigit()) {
            byte |= (hexStr[i].unicode() - '0');
        } else if (hexStr[i].isUpper()) {
            byte |= (hexStr[i].unicode() - 'A' + 10);
        } else if (hexStr[i].isLower()) {
            byte |= (hexStr[i].unicode() - 'a' + 10);
        }
    }
    return byte;
}


void MainWindow::save_image_from_hex(const QString& input_file, const QString& output_image_file) {
    QFile inputFile(input_file);
    if (!inputFile.open(QIODevice::ReadOnly | QIODevice::Text)) {
        qCritical() << "无法打开文件:" << input_file;
        return;
    }

    vector<unsigned char> imageData;
    QTextStream in(&inputFile);
    QString line;

    // 逐行读取16进制数据
    while (!in.atEnd()) {
        line = in.readLine();
        QStringList hexStrings = line.split(" ", QString::SkipEmptyParts);

        for (const QString& byteStr : hexStrings) {
            unsigned char byte = hex_to_byte(byteStr);
            imageData.push_back(byte);
        }
    }

    inputFile.close();

    // 将字节数据保存为图片文件
    QFile outputFile(output_image_file);
    if (!outputFile.open(QIODevice::WriteOnly)) {
        qCritical() << "无法创建文件:" << output_image_file;
        return;
    }

    outputFile.write(reinterpret_cast<const char*>(imageData.data()), imageData.size());
    outputFile.close();

    QPixmap pixmap(output_image_file);
    ui->label_9->setPixmap(pixmap);

    qDebug() << "图片已保存到:" << output_image_file;
}

void MainWindow::showWaveBtn()
{
    if(!clickedShowWaveBtn)
    {
        sw.setFixedSize(1360,700);
        sw.showNormal();
        sw.move(QPoint(0,0));
        sw.setWindowTitle("Display Wave!");
        sw.show();

        connect(hd,SIGNAL(send_Handle_Data()),&sw,SLOT(test()),Qt::QueuedConnection);
        hd->start(QThread::NormalPriority);

        clickedShowWaveBtn = true;
    }
    else
    {
        QMessageBox::warning(this,tr("Warning!!!"),tr("The wave window has been displayed!"),QMessageBox::Abort);
        hd->stop();
    }
}

void MainWindow::initialSerial()
{
    ui->portName->addItem("COM3");
    ui->portName->addItem("COM1");
    ui->portName->addItem("COM2"); 
    ui->portName->addItem("COM4");
    ui->portName->addItem("COM5");
    ui->portName->addItem("COM6");
    ui->portName->addItem("COM7");
    ui->portName->addItem("COM8");
   //  ui->portName->addItem("COM9");
   // ui->portName->addItem("COM12");
    ui->portName->addItem("COM13");

    ui->baudRate->addItem("9600");
    ui->baudRate->addItem("1200");
    ui->baudRate->addItem("2400");
    ui->baudRate->addItem("4800");
    ui->baudRate->addItem("14400");
    ui->baudRate->addItem("19200");
    ui->baudRate->addItem("38400");
    ui->baudRate->addItem("56000");
    ui->baudRate->addItem("115200");
    ui->baudRate->addItem("128000");
    ui->baudRate->addItem("256000");

    ui->dataBits->addItem("8");
    ui->dataBits->addItem("5");
    ui->dataBits->addItem("6");
    ui->dataBits->addItem("7");

    ui->parityCom->addItem("none");
    ui->parityCom->addItem("odd");//奇校验
    ui->parityCom->addItem("even");//偶校验

    ui->stopBit->addItem("1");
    ui->stopBit->addItem("1.5");
    ui->stopBit->addItem("2");

    ui->flowType->addItem("off");
    ui->flowType->addItem("hardware");
    ui->flowType->addItem("xonxoff");
}

// 将 QByteArray 转换为16进制字符串
QString MainWindow::convertToHex(const QByteArray &data)
{
    QString hexStr;
    for (int i = 0; i < data.size(); ++i) {
        hexStr.append(QString::asprintf("%02X ", static_cast<unsigned char>(data[i])));
    }
    return hexStr.trimmed();  // 去掉末尾的空格
}

/*
void MainWindow::readMyCom()
{
    if(read_display_mutex == READ_DATA)
     {
         temp = myCom->readAll();

         if(temp.isEmpty())
         {
             return ;
         }
         if(!clickedShowWaveBtn)
         {
             read_display_mutex = READ_DATA;
         }
         else
         {
             //if(ui->tenPreRadio->isChecked() || ui->twelPreRadio->isChecked())
             //{
               //  processShareData();
             //}
             //else
             //{
               //  readData = temp;
             //}
             readData = temp;

             read_display_mutex = DISPLAY_DATA;
         }

         showPlainText();
         temp.clear();
         qDebug()<<"readData!";
     }
 }*/
/*1112
// 读取串口数据并显示
void MainWindow::readMyCom()
{
    if (read_display_mutex == READ_DATA)
    {
        temp = myCom->readAll();

        if (temp.isEmpty())
        {
            return;
        }

        if (!clickedShowWaveBtn)
        {
            read_display_mutex = READ_DATA;
        }
        else
        {
            readData = temp;
            read_display_mutex = DISPLAY_DATA;
        }
        QString hexData = convertToHex(temp);

        // 显示16进制字符串
        //qDebug() << "Hex Data: " << hexData;
        //ui->reciveData_2->setPlainText(hexData);  // 直接显示在TextEdit控件中
        ui->reciveData->append(hexData);
        showPlainText();  // 在界面上显示数据
        temp.clear();
        qDebug() << "readData!";
    }
}
*/

//合并前代码

void MainWindow::readMyCom()
{
    QStringList framestring;
    //framestring.clear();

    if (read_display_mutex == READ_DATA)
    {
        temp = myCom->readAll();

        if (temp.isEmpty())
        {
          //  on_pushButton_27_clicked();
            return;
        }

        // 设置帧头和帧尾
        QByteArray frameStart = QByteArray::fromHex("FFAA");
        QByteArray frameEnd = QByteArray::fromHex("FFAB");

        // 用于存储拆分出来的所有帧
        QList<QByteArray> frames;
        //frames.clear();

            // 使用一个指针来追踪当前扫描的位置
            int startPos = 0;

            while (startPos < temp.size()) {
                // 查找帧头
                int frameStartPos = temp.indexOf(frameStart, startPos);
                if (frameStartPos == -1) {
                    break; // 如果没有找到帧头，跳出循环
                }

                // 查找帧尾
                int frameEndPos = temp.indexOf(frameEnd, frameStartPos + frameStart.size());
                if (frameEndPos == -1) {
                    break; // 如果没有找到帧尾，跳出循环
                }

                // 提取完整帧数据，包含帧头和帧尾
                QByteArray frame = temp.mid(frameStartPos, frameEndPos - frameStartPos + frameEnd.size());

                while (frame.contains(0xFF)) {
                    frame.remove(frame.indexOf(0xFF), 1);  // 删除所有 0xFF 字节
                }
                while (frame.contains(0xAA)) {
                    frame.remove(frame.indexOf(0xAA), 1);  // 删除所有 0xFF 字节
                }
                while (frame.contains(0xAB)) {
                    frame.remove(frame.indexOf(0xAB), 1);  // 删除所有 0xFF 字节
                }

                if(frame.toHex().size()<1)
                {
                }
                else
                {
                // 将该帧添加到帧列表中
                    QString oneframe = QString(frame);
                    ui->reciveData->append(oneframe);
                    //oneframe.remove(QRegExp("?"));

                    frames.append(frame);
                    framestring.append(oneframe);
                }

                // 更新扫描位置
                startPos = frameEndPos + frameEnd.size();
        }

        if (framestring.isEmpty())
        {
             //QString abc = framestring.last();
             //qDebug()<<abc1;

        }
        else
        {

        QString abc = framestring.last();
        //int yq = framestring.size();
        //QString abc = framestring[yq-1];
        qDebug()<<abc;
        drawRectOnLabel(ui->label_10, abc);
        QString input1 = "01";
        int value = input1.toInt(); // value 变为 1
        ui->lineEdit_6->setText(QString::number(value)); // 显示 "1"
        on_pushButton_27_clicked();
        }
        framestring.clear();
        frames.clear();

    }
}



/*
// 读取串口数据并显示
void MainWindow::readMyCom_photo()
{
    if (read_display_mutex == READ_DATA)
    {
        temp1 = myCom->readAll();

        if (temp1.isEmpty())
        {
            return;
        }
        else
        {
            readData = temp1;
            read_display_mutex = DISPLAY_DATA;
        }
        QString hexData = convertToHex(temp1);

        // 显示16进制字符串
        qDebug() << "Hex Data: " << hexData;
        //ui->reciveData_2->setPlainText(hexData);  // 直接显示在TextEdit控件中
        ui->reciveData_2->append(hexData);
        showPlainText();  // 在界面上显示数据
        temp1.clear();
        qDebug() << "readData!";
    }
}
*/

void MainWindow::readMyCom_photo()
{
    if (read_display_mutex == READ_DATA)
    {
        temp1 = myCom->readAll();

        if (temp1.isEmpty())
        {
            return;
        }
        buffer.append(temp1); // 将新数据追加到缓存
        if(buffer.size()>17000){
      //  qDebug() << "当前缓冲区数据: " << buffer.toHex();
        qDebug() << "当前缓冲区字节数: " << buffer.size();
        }// 查找帧头
        while(true)
       {
        int frameStart = buffer.indexOf(QByteArray::fromHex("FFD8"));
        if (frameStart == -1) {
            // 如果找不到帧头，说明没有完整帧
                    break;
        }

        // 查找帧尾，从帧头之后开始
        int frameEnd = buffer.indexOf(QByteArray::fromHex("FFD9"), frameStart + 2);
        if (frameEnd == -1) {
            // 如果没有找到帧尾，说明帧未接收完整，退出等待下次定时器触发

            break;
        }
        int frameLength = frameEnd - frameStart + 2;
        QByteArray frame1 = buffer.mid(frameStart, frameLength);
        qDebug() << "提取的帧数据: " << frame1.toHex();
        qDebug() << "zhenwei: " << frameEnd;
        processFrame(frame1);
        photo_num += 1;
        //ui->progressBar->setValue(photo_num+3);
        buffer.remove(0, frameEnd + 2);
        photo_flag=0;
        ui->progressBar->setValue(100);
        photo_process=0;
    }

        qDebug() << "readData!";
        if(photo_flag==1)
        {
        photo_process=photo_process+5;
        ui->progressBar->setValue(photo_process);
}}
}
/*
void MainWindow::readMyCom_boom()
{
    if (read_display_mutex == READ_DATA)
    {
        QByteArray data_boom = myCom->readAll();

        if(data_boom.size() < 28){
             qDebug() << "数据长度不足28字节";
          //   boom_flag=0;

             return;
         }
        data_boom = data_boom.left(28);

        if ((uchar)data_boom.at(0) != 0x24 || (uchar)data_boom.at(27) != 0x40) {
               qDebug() << "帧头或帧尾错误";
             //  boom_flag=0;

               return;
           }

        ui->reciveData_2->append(data_boom.toHex().toUpper());
        // 温度计算：使用 A[17] 和 A[18]
        // 公式：float(((a[17]*256 + a[18]) >> 2) * 0.03125)
            uchar b17 = (uchar)data_boom.at(17);
            uchar b18 = (uchar)data_boom.at(18);
            int tempRaw = ((int)b17 << 8) | (int)b18;
            tempRaw = tempRaw >> 2; // 右移2位
            float temperature = tempRaw * 0.03125f;
            ui->lineEdit_3->setText(QString::number(temperature, 'f', 5));

             // 压力计算：使用 A[14]、A[15]、A[16]
            uchar b14 = (uchar)data_boom.at(14);
            uchar b15 = (uchar)data_boom.at(15);
            uchar b16 = (uchar)data_boom.at(16);
            int pressureRaw = ((b14 & 0x7F) << 16) | (b15 << 8) | b16;
            float pressure = 0.0f;
               // 如果 A[14] 的最高位为1，则生成随机数在 0.10000 到 0.128552 之间
               if (b14 & 0x80) {
                  // float range = 0.128552f - 0.10000f;  // 0.028552
                  // pressure = 0.10000f + QRandomGenerator::global()->bounded(range);
                   pressure=0.0981456;
               } else {
                   pressure = (pressureRaw / float(pow(2,23))) * 256.0f / 200.0f * 60.0f;
                   pressure =pressure*2369.07;
               }
               ui->lineEdit_2->setText(QString::number(pressure, 'f', 5));

               // A[19] 的计算：A[19] * 2
                  uchar b19 = (uchar)data_boom.at(19);
                  int a19_val = b19 * 2;
               ui->lineEdit_4->setText(QString::number(a19_val));

                  qDebug() << "数据解析完成";
                  boom_flag=0;
                  flagResetTimer->stop();
             }
}
*/


void MainWindow::readMyCom_boom()
{
    if (read_display_mutex == READ_DATA)
    {
        QByteArray newData = myCom->readAll();
        // 保留最后100字节防止内存溢出（可根据实际情况调整）

        if(newData.isEmpty()) return;

          buffer111.append(newData); // 将新数据追加到缓存
          if(buffer111.size() > 50) buffer111 = buffer111.right(50);
          bool frameFound = false;

          for(int i = buffer111.size() - 25; i >= 0; --i)
          {

                  // 验证帧头
                  if(buffer111.mid(i, 2) != QByteArray::fromHex("CEC2")) continue;

                  // 验证帧长度
                  if(buffer111.size() - i >= 25)
                {

                  // 提取完整帧
                  QByteArray frame25 = buffer111.mid(i, 25);

                  // 验证帧尾
                  if(frame25.right(2) == QByteArray::fromHex("D70A"))
                  {
                  qDebug() << "找到25字节完整帧:" << frame25.toHex();
                  // 显示有效数据
                  qDebug() << "温度:" << frame25.mid(5, 4).toHex()  // 示例位置
                           << "深度:" << frame25.mid(18, 4).toHex(); // 示例位置
                  // 2. 解析温度（5-8字节）
                   QByteArray tempBytes = frame25.mid(5, 4);
                   QString temperature1 = QString::fromLatin1(tempBytes);
                   // 3. 解析深度（16-19字节）
                   QByteArray depthBytes = frame25.mid(18, 4);
                   QString depth1 = QString::fromLatin1(depthBytes);
                   double tempVal = depth1.toDouble();
                   double pressureVal = ((tempVal / 0.009955) + 1003) / 10000;
                   QString pressure1 = QString::number(pressureVal, 'f', 4);
                   double T = temperature1.toDouble();
                   double D = tempVal;
                   // 这里假设压力P是根据深度D计算得到的：
                   double P = pressureVal;
                   // 更新界面显示
                   ui->lineEdit_8->setText(depth1);
                   ui->lineEdit_7->setText(temperature1);
                   ui->lineEdit_9->setText(pressure1);
                   updateChartWithData(T, D, P);
                  // 清理缓冲区（保留后续数据）
                  buffer111 = buffer111.mid(i + 25);
                  frameFound = true;
                  break;
              }
            }
                  if (buffer111.size() - i >= 24)
                         {
                             QByteArray frame24 = buffer111.mid(i, 24);
                  // 验证帧尾
                  if(frame24.right(2) == QByteArray::fromHex("D70A"))
                  {
                  qDebug() << "找到25字节完整帧:" << frame24.toHex();
                  // 显示有效数据
                  qDebug() << "温度:" << frame24.mid(5, 4).toHex()  // 示例位置
                           << "深度:" << frame24.mid(17, 4).toHex(); // 示例位置
                  // 2. 解析温度（5-8字节）
                   QByteArray tempBytes = frame24.mid(5, 4);
                   QString temperature1 = QString::fromLatin1(tempBytes);
                   // 3. 解析深度（16-19字节）
                   QByteArray depthBytes = frame24.mid(17, 4);
                   QString depth1 = QString::fromLatin1(depthBytes);
                   double tempVal = depth1.toDouble();
                   double pressureVal = ((tempVal / 0.009955) + 1003) / 10000;
                   QString pressure1 = QString::number(pressureVal, 'f', 4);
                   double T = temperature1.toDouble();
                   double D = tempVal;
                   // 这里假设压力P是根据深度D计算得到的：
                   double P =pressureVal;
                   // 更新界面显示
                   ui->lineEdit_8->setText(depth1);
                   ui->lineEdit_7->setText(temperature1);
                   ui->lineEdit_9->setText(pressure1);
                   updateChartWithData(T, D, P);


                  // 清理缓冲区（保留后续数据）
                  buffer111 = buffer111.mid(i + 24);
                  frameFound = true;
                  break;
              }
            }
          }
          if(!frameFound) {
                  qDebug() << "未找到完整帧，当前缓冲区:" << buffer111.toHex();
                  boom_flag=0;
                  flagResetTimer->stop();

              }
               qDebug() << "数据解析完成";
                  boom_flag=0;
                  flagResetTimer->stop();
             }
}


// 处理完整帧数据
void MainWindow::processFrame(const QByteArray &frame)
{
    // 打印帧数据
    //qDebug() << "Received Frame: " << frame.toHex().toUpper();

    // 如果需要显示在界面
    //ui->reciveData_2->append(frame.toHex(' ').toUpper());

   // QString hexData = convertToHex(frame);
    QString hexstring = convertToHex(frame);
    photonum = QString::number(photo_num,10);
    photoptr = "D:/open_sour/received_data" + photonum + ".txt";
    photoshowptr = "D:/open_sour/restored_image" + photonum + ".jpg";

    QFile file(photoptr);
    if(file.exists(photoptr))
        {
        file.remove(photoptr);
    }// 创建文件
          if (file.open(QIODevice::Append | QIODevice::Text)) {
              QTextStream out(&file);
              out << hexstring << "\n";  // 将帧数据转换为16进制字符串并写入文件
              file.close();  // 关闭文件
          } else {
              qDebug() << "无法打开文件进行写入!";
          }
    save_image_from_hex(photoptr,photoshowptr);
    // 显示16进制字符串
    //qDebug() << "Hex Data: " << hexData;
    //ui->reciveData_2->setPlainText(hexData);  // 直接显示在TextEdit控件中
    //ui->reciveData_2->append(hexData);
    // 如果需要保存到文件或进一步处理
    //saveFrameToFile(frame);

    // 设置标志位或触发后续操作
   // frameComplete = true;
}
 void MainWindow::showPlainText()
{
    if(!stopShow)
    {
        if(temp.isEmpty())
        {
            return ;
        }
        /*if(ui->autoShowCheck->isChecked())
        {
            if(ui->reciveData->isForwardAvailable())
                ui->reciveData->clear();
        }*/

        if(ui->hexShowCheck->isChecked())
        {
            //ui->reciveData->insertPlainText(stringSpaceToHex(temp.toHex(),' '));
            //ui->reciveData->append(stringSpaceToHex(temp.toHex(),' '));
            ui->reciveData->append(temp.data());
        }
        else
        {
            //ui->reciveData->insertPlainText(temp);
            ui->reciveData->append(temp.data());
            //将串口的数据显示在窗口的文本浏览器中
        }

        //qDebug()<<temp<<" bytes! "<<"\n";

        /*const char fileName[]="./test_data.txt";
        ofstream  fout(fileName,ios::app|ios::out);
        fout<<"This is a Qt program!";
        fout<<hex<<"Hello qorld!";
        fout<<(ui->reciveData->toPlainText().constData());
        fout<<ends;
        fout.close();*/
    }
    else
    {
        myCom->readAll();
        ui->reciveData->insertPlainText("");
    }
}

QString MainWindow::stringSpaceToHex(QByteArray str,char tag)
{
    int length=str.length();
    //qDebug()<<str<<"\n";

    QString result="";
    int j=0;
    for(int i=0;i<length;i+=2)
    {
        result[j]=str[i];
        result[j+1]=str[i+1];
        result[j+2]=tag;
        j+=3;
    }

    qDebug()<<result<<"\n";
    return result;
}

void MainWindow::sendDataBtn()
{
    if(ui->sendDataEdit->text()=="")
        QMessageBox::warning(this,tr("Warning!"),tr("Cann't send empty string!\n   Try again1"),QMessageBox::Ok);
    myCom->write(ui->sendDataEdit->text().toLatin1());
    qDebug()<<"write:"<<myCom->bytesToWrite()<<"bytes";//要发送的字节数
}

void MainWindow::openSerial()
{
    //connect(cd,SIGNAL(coleectDataNow()),this,SLOT(readMyCom()),Qt::DirectConnection);
    //cd->start(QThread::HighPriority);
    connect(time,SIGNAL(timeout()),this,SLOT(timeToReadCom()));

    QString portName=ui->portName->currentText();
    qDebug()<< portName;
    QString baudRate=ui->baudRate->currentText();
    QString dataBits=ui->dataBits->currentText();
    QString parity=ui->parityCom->currentText();
    QString stopBit=ui->stopBit->currentText();
    QString flow=ui->flowType->currentText();

    if(ui->eightPreRadio->isChecked())
    {
        precision_data = 8;
    }
    else if(ui->tenPreRadio->isChecked())
    {
        precision_data = 10;
    }
    else if(ui->twelPreRadio->isChecked())
    {
        precision_data = 12;
    }

    myCom=new Win_QextSerialPort(portName,QextSerialBase::EventDriven);
    //connect(myCom,SIGNAL(readyRead()),this,SLOT(readMyCom()));
    myCom->open(QIODevice::ReadWrite);
    //timeId  = startTimer(1000);
    time->start(600);

    if(baudRate==tr("1200"))
        myCom->setBaudRate(BAUD1200);
    else if(baudRate==tr("1800"))
        myCom->setBaudRate(BAUD1800);
    else if(baudRate==tr("2400"))
        myCom->setBaudRate(BAUD2400);
    else if(baudRate==tr("4800"))
        myCom->setBaudRate(BAUD4800);
    else if(baudRate==tr("9600"))
        myCom->setBaudRate(BAUD9600);
    else if(baudRate==tr("14400"))
        myCom->setBaudRate(BAUD14400);
    else if(baudRate==tr("19200"))
        myCom->setBaudRate(BAUD19200);
    else if(baudRate==tr("38400"))
        myCom->setBaudRate(BAUD38400);
    else if(baudRate==tr("56000"))
        myCom->setBaudRate(BAUD56000);
    else if(baudRate==tr("115200"))
        myCom->setBaudRate(BAUD115200);
    else if(baudRate==tr("128000"))
        myCom->setBaudRate(BAUD128000);
    else if(baudRate==tr("256000"))
        myCom->setBaudRate(BAUD256000);

    if(dataBits==tr("5"))
        myCom->setDataBits(DATA_5);
    else if(dataBits==tr("6"))
        myCom->setDataBits(DATA_6);
    else if(dataBits==tr("7"))
        myCom->setDataBits(DATA_7);
    else if(dataBits==tr("8"))
        myCom->setDataBits(DATA_8);

    if(parity==tr("none"))
        myCom->setParity(PAR_NONE);
    else if(parity==tr("odd"))
        myCom->setParity(PAR_ODD);
    else if(parity==tr("even"))
        myCom->setParity(PAR_EVEN);

    if(stopBit==tr("1"))
        myCom->setStopBits(STOP_1);
    else if(stopBit==tr("1.5"))
        myCom->setStopBits(STOP_1_5);
    else if(stopBit==tr("2"))
        myCom->setStopBits(STOP_2);

    if(flow==tr("off"))
        myCom->setFlowControl(FLOW_OFF);
    if(flow==tr("hardware"))
        myCom->setFlowControl(FLOW_HARDWARE);
    if(flow==tr("xonxoff"))
        myCom->setFlowControl(FLOW_XONXOFF);

    //myCom->setFlowControl(FLOW_OFF);//数据流控制设置，设置为无数据流控制
    myCom->setTimeout(500);

    ui->openSerial->setEnabled(false);
    ui->closeSerial->setEnabled(true);
    ui->sendDataBtn->setEnabled(true);
    ui->portName->setEnabled(false);
    ui->baudRate->setEnabled(false);
    ui->dataBits->setEnabled(false);
    ui->parityCom->setEnabled(false);
    ui->stopBit->setEnabled(false);
    ui->flowType->setEnabled(false);
    ui->closeSerial->setEnabled(true);
    ui->showWaveBtn->setEnabled(true);
    ui->selectFileBtn->setEnabled(true);
    ui->clearReceiveBtn->setEnabled(true);
    ui->clearSendBtn->setEnabled(true);
    ui->saveShowData->setEnabled(true);
    ui->stopShowBtn->setEnabled(true);
    ui->sendDataEdit->setEnabled(true);
    ui->autoSend->setEnabled(true);
    ui->autoShowCheck->setEnabled(true);
    ui->hexShowCheck->setEnabled(true);
    ui->sendFileBtn->setEnabled(false);
    ui->eightPreRadio->setEnabled(false);
    ui->tenPreRadio->setEnabled(false);
    ui->twelPreRadio->setEnabled(false);

    autoSendTime=new AutoSendData(myCom);
}

void MainWindow::closeSerial()
{
    myCom->close();
    //this->killTimer(timeId);
    time->stop();
    hd->terminate();

    ui->openSerial->setEnabled(true);
    ui->closeSerial->setEnabled(false);
    ui->sendDataBtn->setEnabled(false);
    ui->portName->setEnabled(true);
    ui->baudRate->setEnabled(true);
    ui->dataBits->setEnabled(true);
    ui->parityCom->setEnabled(true);
    ui->stopBit->setEnabled(true);
    ui->flowType->setEnabled(true);
    ui->showWaveBtn->setEnabled(false);
    ui->selectFileBtn->setEnabled(false);
    ui->clearReceiveBtn->setEnabled(false);
    ui->clearSendBtn->setEnabled(false);
    ui->saveShowData->setEnabled(false);
    ui->stopShowBtn->setEnabled(false);
    ui->sendDataEdit->setEnabled(false);
    ui->autoSend->setEnabled(false);
    ui->autoShowCheck->setEnabled(false);
    ui->hexShowCheck->setEnabled(false);
    ui->sendFileBtn->setEnabled(false);
    ui->eightPreRadio->setEnabled(true);
    ui->tenPreRadio->setEnabled(true);
    ui->twelPreRadio->setEnabled(true);

    delete myCom;
    myCom = NULL;
    //unlink("./shareData.txt");
}

MainWindow::~MainWindow()
{
    delete ui;

    if(myCom != NULL)
       delete myCom;
}

void MainWindow::timeToReadCom()
{
    if (photo_flag)
    {
       readMyCom_photo();
    }else if(boom_flag)
    {    readMyCom_boom();
}
    else{
    readMyCom();
        }
}

void MainWindow::closeEvent(QCloseEvent* e)
{
    this->close();
    sw.close();
    //unlink("./shareData.txt");
}

void MainWindow::closeWindow()
{
    this->close();
    sw.close();

    //unlink("./shareData.txt");
}


void MainWindow::clearSendArea()
{
    ui->sendDataEdit->clear();
}

void MainWindow::clearReceiveDataArea()
{
    ui->reciveData->clear();
}

void MainWindow::stopShowData()
{
    if(!stopShow)
    {
        ui->stopShowBtn->setText(tr("继续显示"));
        stopShow=true;
    }
    else
    {
        ui->stopShowBtn->setText(tr("停止显示"));
        stopShow=false;
    }
}

void MainWindow::saveShowData()
{
    QString path="./";
    QString fileName=QFileDialog::getSaveFileName(this,
                                                  tr("Save Files(*.txt)"),
                                                  path,
                                                  tr("txt files(*.txt)"));
    if(fileName.isNull())
    {
        QMessageBox::warning(this,tr("File Name Error!"),tr("file name cann't be null!"),QMessageBox::Ok);
    }
    else
    {
        QFile saveFile;
        saveFile.setFileName(fileName);
        if(saveFile.open(QIODevice::ReadWrite|QFile::Text))
        {
            QTextStream saveFileStream(&saveFile);
            saveFileStream<<ui->reciveData->toPlainText();
            saveFileStream.atEnd();
            saveFile.close();
        }
    }
}

void MainWindow::SelectSendFileData()
{
    QString path="./";
    QString fileName=QFileDialog::getOpenFileName(this,
                                                  tr("Select Files(*.txt)"),
                                                  path,
                                                  tr("txt files(*.txt)"));
    if(fileName.isNull())
    {
        QMessageBox::warning(this,tr("File Name Error!"),tr("file name cann't be null!"),QMessageBox::Ok);
    }
    else
    {
        QFile openFile;
        openFile.setFileName(fileName);
        if(openFile.open(QIODevice::ReadOnly|QFile::Text))
        {
            QTextStream openFileStream(&openFile);
            openFileStream>>strSelectFileData,
            openFileStream.atEnd();
            openFile.close();
        }
    }
    ui->sendFileBtn->setEnabled(true);

    if(strSelectFileData=="")
    {
        QMessageBox::warning(this,tr("Warning!"),tr("没有选择文件或者选择的文件为空!\n请重新选择文件后再发送!"),QMessageBox::Ok);
        return ;
    }
    ui->sendDataEdit->clear();
    ui->sendDataEdit->setText(strSelectFileData);
}

void MainWindow::sendFileData()
{
    myCom->write(ui->sendDataEdit->text().toLatin1());
    strSelectFileData="";
    ui->sendFileBtn->setEnabled(false);
    ui->selectFileBtn->setEnabled(true);
}

void MainWindow::autoSendTimeSet()
{
    autoSendTime->setWindowTitle("Auto Send!");
    autoSendTime->show();
}


/*void MainWindow::timerEvent(QTimerEvent *e)
{
    readMyCom();
}*/

void MainWindow::processShareData()
{
    /*int j = 0;
    ofstream fout("./shareData.txt",ios::app|ios::out);
    fout<<temp.constData();
    fout.close();*/
}

void MainWindow::iconSystemActived(QSystemTrayIcon::ActivationReason reason)
{
}

void MainWindow::showAbout()
{
    af.show();
}

void MainWindow::startthread()
{
    thread_1->start(QThread::HighPriority);
}









void MainWindow::on_openSerial_clicked()
{
    ui->label_12->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    //// 初始化滚动条
    horizontalScroll = new QScrollBar(Qt::Horizontal, this);
    horizontalScroll->setRange(0, 0);
    horizontalScroll->setPageStep(15);  // 每页显示15个数据点
    ui->verticalLayout->addWidget(horizontalScroll); // 将滚动条添加到界面布局
    ui->label_2->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->widget->addGraph();  // T曲线（索引0）
        ui->widget->graph(0)->setPen(QPen(Qt::green));
        ui->widget->graph(0)->setName("T");

        ui->widget->addGraph();  // D曲线（索引1）
        ui->widget->graph(1)->setPen(QPen(Qt::blue));
        ui->widget->graph(1)->setName("D");

        ui->widget->addGraph();  // P曲线（索引2）
        ui->widget->graph(2)->setPen(QPen(Qt::red));
        ui->widget->graph(2)->setName("P");
        ui->widget->rescaleAxes(true);

        // 让图例背景透明

        // **手动微调范围，确保曲线显示完整**
       // ui->widget->xAxis->setRange(-60, 60);
       // ui->widget->yAxis->setRange(-5000, 5000);

        // **去掉多余边距，让曲线填满区域**
        ui->widget->plotLayout()->setMargins(QMargins(5, 5, 5, 5));
        //ui->widget->xAxis->setLabel("数据点序号");
        //ui->widget->yAxis->setLabel("参数值");
            ui->widget->legend->setVisible(true);
            ui->widget->setInteractions(QCP::iRangeDrag | QCP::iRangeZoom); // 允许拖拽缩放
            ui->widget->legend->setBrush(QBrush(Qt::NoBrush));
            // 连接滚动条信号
             connect(horizontalScroll, &QScrollBar::valueChanged, [this](int value){
                 autoScroll = false;
                 updateChartView(value);
             });
}

void MainWindow::on_tack_photo_clicked()
{
    //if(ui->sendDataEdit->text()=="")
    //QMessageBox::warning(this,tr("Warning!"),tr("Cann't send empty string!\n   Try again1"),QMessageBox::Ok);
    send_photo.clear();
    ui->progressBar->setMinimum(0);
    ui->progressBar->setMaximum(100);
    ui->progressBar->setValue(0);
    send_photo.append(0x31);
    myCom->write(send_photo);
    photo_flag=1;
    qDebug()<<"write:"<<myCom->bytesToWrite()<<"flag:"<<photo_flag;//要发送的字节数
   // onDraw();
}

void MainWindow::on_sendDataBtn_clicked()
{

}

void MainWindow::onDraw() {
    // 示例数据
    //QPixmap pixmap("D:/open_sour/restored_image0.jpg");
    //ui->label_10->setPixmap(pixmap);
    QString data = "jellfish @ (140 25 333 252) 0.671\n fish @ (250 45 600 368) 0.671\n";

    // 调用函数绘制矩形框
    drawRectOnLabel(ui->label_10, data);
}

void MainWindow::drawRectOnLabel(QLabel *label, const QString &data) {
    // 从 QLabel 获取当前显示的图片
    QPixmap pixmap("D:/open_sour/haidi.jpg");

    //QStringList dataLines = data.split("\n", Qt::SkipEmptyParts);   //分行
    QStringList dataLines = data.split("\n");
    dataLines.removeAll(""); // 移除所有空行
    QPainter painter(&pixmap);
        painter.setPen(QPen(Qt::red, 2)); // 矩形边框颜色
        painter.setFont(QFont("Arial", 14)); // 设置文本字体和大小

        for (const QString &line : dataLines) {
            // 查找括号中的内容
            int zuokuohao = line.indexOf("(");
            int youkuohao = line.indexOf(")");
            if (zuokuohao == -1 || youkuohao == -1) {
                continue; // 如果找不到括号，跳过此行
            }

    QString coordinates = line.mid(zuokuohao + 1, youkuohao - zuokuohao - 1);
    QStringList coords = coordinates.split(" ");
            if (coords.size() < 4) {
                continue; // 坐标格式不正确，跳过此行
            }
            // 解析坐标
                   int xlavel_1 = coords[0].toInt();
                   int ylavel_1 = coords[1].toInt();
                   int xlavel_2 = coords[2].toInt();
                   int ylavel_2 = coords[3].toInt();

                   int width = xlavel_2 - xlavel_1;
                   int height = ylavel_2 - ylavel_1;
                   if(width>630||height>470)
                   {}
                   else
                   {
                   // 获取目标名称和置信度
                   QStringList parts = line.split(" ");
                   if (parts.size() < 2) {
                       continue; // 数据格式不正确，跳过此行
                   }

        QString class_name = parts[0]; // 目标名称
        //**3.4日新家代码  分类识别
        if(tongji_flag==1)
        {
        if (class_name == "fish") {
            ui->label_34->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "coral") {
            ui->label_35->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "scallop") {
            ui->label_36->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "echinide") {
            ui->label_37->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "starfish") {
            ui->label_38->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "calamari") {
            ui->label_39->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "turtle") {
            ui->label_40->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "jellfish") {
            ui->label_41->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        if (class_name == "diver") {
            ui->label_52->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
        }
        }
        if (class_name == "fissure") {
            ui->label_2->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
            on_tack_photo_clicked();
        }      
        QString confidence = parts.last(); // 置信度
         // 绘制矩形框
        painter.drawRect(QRect(xlavel_1, ylavel_1, width, height));
                      // 绘制文本（目标名称 + 置信度）
        int text_x = xlavel_1;
        int text_y = ylavel_1 - 10; // 微调文本位置到矩形框上方
        painter.drawText(text_x, text_y, class_name + " ：" + confidence);
       }
        }
        painter.end(); // 结束绘制
    label->setPixmap(pixmap);

}



void MainWindow::on_closeSerial_clicked()
{
    ui->label_12->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");

}

void MainWindow::on_tack_photo_3_clicked()
{

    ui->label_34->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_35->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_36->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_37->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_38->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_39->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_40->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_41->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_52->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    tongji_flag=1;
    /*
    ui->label_34->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_35->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_36->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_37->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_38->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_39->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_40->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_41->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
    ui->label_52->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
*/

    timer_count->start(800);  // 每 1 秒更新一次

}

void MainWindow::on_tack_photo_4_clicked()
{
    ui->label_34->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_35->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_36->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_37->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_38->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_39->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_40->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_41->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    ui->label_52->setStyleSheet("QLabel { background-color: rgb(0, 0, 0); }");
    timer_count->stop();  // 每 1 秒更新一次
    ui->lineEdit_10->clear();
}

void MainWindow::on_pushButton_2_clicked()
{
    ui->label_2->setStyleSheet("QLabel { background-color: rgb(0, 255, 0); }");
}

void MainWindow::on_pushButton_25_clicked()
{
    //if(ui->sendDataEdit->text()=="")
    //QMessageBox::warning(this,tr("Warning!"),tr("Cann't send empty string!\n   Try again1"),QMessageBox::Ok);

    shoudong_mode.clear();
    shoudong_mode.append(0x32);
    myCom->write(shoudong_mode);
    //photo_flag=1;
    qDebug()<<"write:"<<myCom->bytesToWrite()<<"flag:"<<shoudong_mode;//要发送的字节数
}

void MainWindow::on_pushButton_24_clicked()
{
    zidong_mode.clear();
    zidong_mode.append(0x33);
    myCom->write(zidong_mode);
    //photo_flag=1;
    qDebug()<<"write:"<<myCom->bytesToWrite()<<"flag:"<<zidong_mode;//要发送的字节数
    updateGreenLabelCount();
}

void MainWindow::on_pushButton_23_clicked()
{
    detect.clear();
    detect.append(0x34);
    myCom->write(detect);
    //photo_flag=1;
    qDebug()<<"write:"<<myCom->bytesToWrite()<<"flag:"<<detect;//要发送的字节数
    QString input = "01";
    int value = input.toInt(); // value 变为 1
    ui->lineEdit_6->setText(QString::number(value)); // 显示 "1"
}

void MainWindow::updateGreenLabelCount()
{
    int greenCount = 0;
    QList<QLabel*> labels = {
        ui->label_34, ui->label_35, ui->label_36,
        ui->label_37, ui->label_38, ui->label_39,
        ui->label_40, ui->label_41, ui->label_52
    };

    for (QLabel* label : labels) {
        if (label->styleSheet().contains("rgb(0, 255, 0)", Qt::CaseInsensitive)) {
            greenCount++;
        }
    }
    // 在 lineEdit_10 上显示绿色的 QLabel 数量
    ui->lineEdit_10->setText(QString::number(greenCount));
}

void MainWindow::on_tack_photo_2_clicked()
{
    ui->label_34->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_35->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_36->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_37->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_38->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_39->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_40->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_41->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->label_52->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
    ui->lineEdit_10->clear();
}

void MainWindow::on_pushButton_18_clicked()
{

}

void MainWindow::on_pushButton_21_clicked()
{

    QPixmap pix1("D:/open_sour/output3.jpg"); // 替换为你的图片路径
    ui->label_9->setPixmap(pix1);
    ui->label_2->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
     ui->progressBar->setValue(100);


}

void MainWindow::on_pushButton_19_clicked()
{
    QPixmap pix2("D:/open_sour/output1.jpg"); // 替换为你的图片路径
    ui->label_9->setPixmap(pix2);
   // ui->label_2->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
     ui->progressBar->setValue(100);
}

void MainWindow::on_pushButton_4_clicked()
{
    /*
    QString newData = "241C130D00000000000000090D458000000D4528000218580000C540";
    ui->reciveData_2->append(newData+'\n');
    //QString currentText = ui->reciveData_2->toPlainText();
    //QString combinedText = newData + "\n" + currentText;
    //ui->reciveData_2->setPlainText(combinedText);
    ui->lineEdit_2->setText(QString("-0.02977"));
    ui->lineEdit_3->setText(QString("26.5"));
    ui->lineEdit_4->setText(QString("80"));
*/
    boom_send.clear();
    boom_send.append(0x24);
    boom_send.append(0x06);
    boom_send.append(0x13);
    boom_send.append(0xF4);
    boom_send.append(0xC5);
    boom_send.append(0x40);
    //send11 = QByteArray::fromHex("240613F4C540");
    myCom->write(boom_send);
      //  myCom->write(send11);
boom_flag=1;
flagResetTimer->start(5000);  // 5 秒倒计时

}

void MainWindow::on_pushButton_27_clicked()
{
    //QPixmap pix1("D:/open_sour/output3.jpg"); // 替换为你的图片路径
  //  ui->label_9->setPixmap(pix1);
   // ui->label_2->setStyleSheet("QLabel { background-color: rgb(255, 0, 0); }");
   //  ui->progressBar->setValue(100);
    boom_flag=1;
 flagResetTimer->start(1500);  // 5 秒倒计时
 detect_wat.clear();
 detect_wat.append(0x35);
 myCom->write(detect_wat);

}



// 更新图表显示范围的函数
void MainWindow::updateChartView(int startIndex)
{
    const int visiblePoints = 15; // 可见点数

    // 计算显示范围
    double minX = startIndex + 1;
    double maxX = qMin(startIndex + visiblePoints, xData.size());

    // 设置X轴范围
    ui->widget->xAxis->setRange(minX - 0.5, maxX + 0.5);

    // 自动计算Y轴范围（仅考虑可见区域）
    QVector<double> visibleYT = yTData.mid(startIndex, visiblePoints);
    QVector<double> visibleYD = yDData.mid(startIndex, visiblePoints);
    QVector<double> visibleYP = yPData.mid(startIndex, visiblePoints);

    double yMin = qMin(qMin(*std::min_element(visibleYT.begin(), visibleYT.end()),
                          *std::min_element(visibleYD.begin(), visibleYD.end())),
                      *std::min_element(visibleYP.begin(), visibleYP.end()));

    double yMax = qMax(qMax(*std::max_element(visibleYT.begin(), visibleYT.end()),
                      *std::max_element(visibleYD.begin(), visibleYD.end())),
                      *std::max_element(visibleYP.begin(), visibleYP.end()));

    ui->widget->yAxis->setRange(yMin - 0.1*(yMax-yMin), yMax + 0.1*(yMax-yMin));

    ui->widget->replot();
}



void MainWindow::updateChartWithData(double T, double D, double P)
{
    // 更新x轴数据：这里简单地让x轴数据递增
    xData.append(xData.isEmpty() ? 1 : xData.last() + 1);

    // 分别保存T、D、P数据
    yTData.append(T);
    yDData.append(D);
    yPData.append(P);

    // 更新滚动条设置
    const int totalPoints = xData.size();
    const int visiblePoints = 15;
    horizontalScroll->setRange(0, qMax(0, totalPoints - visiblePoints));
    horizontalScroll->setPageStep(visiblePoints);

    // 自动滚动逻辑
    if(autoScroll || (totalPoints <= visiblePoints)) {
        horizontalScroll->setValue(totalPoints - visiblePoints);
    }

    // 更新图表数据
    ui->widget->graph(0)->setData(xData, yTData);
    ui->widget->graph(1)->setData(xData, yDData);
    ui->widget->graph(2)->setData(xData, yPData);

    // 更新显示范围（如果需要自动滚动）
    if(autoScroll) {
        updateChartView(qMax(0, totalPoints - visiblePoints));
    }

    ui->widget->replot();
}



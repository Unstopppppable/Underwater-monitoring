#include <serialthread.h>
#include <mainwindow.h>
#include <QThread>

Thread_one::Thread_one()
{

}


void Thread_one::run()
{
   //ainWindow w;

    while(1)
    {

        sleep(5);
       //.readMyCom();
        qDebug()<<readData;
    }
}
